#include <iostream>
#include <ostream>
#include <vector>
#include <string>
#include <map>
#include <bits/stl_tree.h>

int string_test() {
    std::string * str = new std::string();
    std::cout << "Please Input a string:";
    std::cin >> *str;
    
    std::cout << "str length:" << str->length() << std::endl;

    std::cout << "Chars:";
    for(auto ch : *str) {
        std::cout << ch << " ";
    }

    std::cout << "\n";
    return str->size();
}

int vector_int_test() {
    std::vector<int> int_vec;
    std::cout << "input 5 int:";
    for(int i = 0;i < 5; i++) {
        int x;
        std::cin >> x;
        int_vec.push_back(x);
    }
    
    int sum = 0;
    for(int i = 0; i < int_vec.size(); i++) {
        sum += int_vec[i];
    }
    std::cout << "sum:" << sum << std::endl;

    std::cout << "itor test:\n";
    for(auto iter = int_vec.begin(); iter != int_vec.end(); iter++) {
        std::cout << "iter:" << *iter << std::endl;
    }

    return sum;
}

int vector_string_test() {
    int n;
    std::vector<std::string> s_list;
    std::cout << "input a number:";
    std::cin >> n;

    for(int i = 0 ; i < n; i++) {
        std::string s = "student_" + std::to_string(i);
        s_list.push_back(s);
    }

    return s_list.size();
}

int map_string_int_test() {
    
    std::map<std::string, int> * map = new std::map<std::string, int>();
    std::string input_name;
    (*map)["wang"] = 234;
    (*map)["zhang"] = 111;
    (*map)["dog"] = 1123;
    (*map)["Li"] = 1447;

    for(int i = 0; i < 100; i++) {
        (*map)["Fun_" + std::to_string(i)] = i + 1;
    }

    std::cout << "input a name:";
    std::cin >> input_name;
    if (map->count(input_name) > 0) {
        std::cout << "find:" << input_name << ":" << (*map)[input_name] << std::endl;
        return 1;
    } else {
        std::cout << "not found!\n";
        return 0;
    }
}

int main() {
    string_test();
    vector_int_test();
    vector_string_test();
    map_string_int_test();
    return 0;

}